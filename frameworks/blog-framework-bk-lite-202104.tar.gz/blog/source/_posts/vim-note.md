---
title: VIM笔记 
date: 2021-04-16 18:36:03
tags:
- VIM
- 笔记
categories:
- 笔记
- 摘录
---

VIM编辑器是基于命令行的编辑器，是传奇编辑器VI的增强版本，如果你深入地了解过linux系统，那么想必一定认识这个名气不小的软件,相比其他的软件，VIM的闻名，主要是得益于它强大的插件，同时是命令行时代著称的软件，软件简洁，如果熟练使用，几乎可以把鼠标丢掉。
[spf13](https://github.com/spf13/spf13-vim)是比较出名的一个vim插件集成项目，集成了VIM的大部分插件，可以说是一把利器。


<!-- More -->
## SPF13的安装教程
Requires Git 1.7+ and Vim 7.3+
```
curl https://j.mp/spf13-vim3 -L > spf13-vim.sh && sh spf13-vim.sh
```
If you have a bash-compatible shell you can run the script directly:
```
sh <(curl https://j.mp/spf13-vim3 -L)
```
如果因为gfw原因使用以上方法依然无法安装，可以尝试：
```
wget https://raw.githubusercontent.com/spf13/spf13-vim/3.0/bootstrap.sh
sh bootstrap.sh
```

## VIM快捷键教程
Vim 编辑器是一个基于命令行的工具，是传奇编辑器 vi 的增强版。尽管图形界面的富文本编辑有很多，但是熟悉 Vim 对于每一位 Linux 的使用者都能有所帮助——无论你是经验丰富的系统管理员，还是刚上手树莓派的新手用户。
这个轻量级的编辑器是个非常强大的工具。在有经验的使用者手中，它能完成不可思议的任务。除了常规的文本编辑功能以外，它还支持一些进阶特性。例如，基于正则表达式的搜索和替换、编码转换，以及语法高亮、代码折叠等的编程特性。
使用 Vim 时有一个非常重要的一点需要注意，那就是按键的功能取决于编辑器当前的“模式”。例如，在“普通模式”输入字母`j`时，光标会向下移动一行。而当你在“插入模式”下输入字符，则只是正常的文字录入。
下面就是速查表，以便于你充分利用 Vim。

### 基本操作

| 快捷键 | 功能  |
| --- | --- |
| `Esc` | 从当前模式转换到“普通模式”。所有的键对应到命令。 |
| `i` | “插入模式”用于插入文字。回归按键的本职工作。 |
| `:` | “命令行模式” Vim 希望你输入类似于保存该文档命令的地方。 |

### 方向键

| 快捷键 | 功能  |
| --- | --- |
| `h` | 光标向左移动一个字符 |
| `j` 或 `Ctrl + J` | 光标向下移动一行 |
| `k` 或 `Ctrl + P` | 光标向上移动一行 |
| `l` | 光标向右移动一个字符 |
| `0` | （数字 0）移动光标至本行开头 |
| `$` | 移动光标至本行末尾 |
| `^` | 移动光标至本行第一个非空字符处 |
| `w` | 向前移动一个词 （上一个字母和数字组成的词之后） |
| `W` | 向前移动一个词 （以空格分隔的词） |
| `5w` | 向前移动五个词 |
| `b` | 向后移动一个词 （下一个字母和数字组成的词之前） |
| `B` | 向后移动一个词 （以空格分隔的词） |
| `5b` | 向后移动五个词 |
| `G` | 移动至文件末尾 |
| `gg` | 移动至文件开头 |

### 浏览文档

| 快捷键 | 功能  |
| --- | --- |
| `(` | 跳转到上一句 |
| `)` | 跳转到下一句 |
| `{` | 跳转到上一段 |
| `}` | 跳转到下一段 |
| `[[` | 跳转到上一部分 |
| `]]` | 跳转到下一部分 |
| `[]` | 跳转到上一部分的末尾 |
| `][` | 跳转到上一部分的开头 |

### 插入文本

| 快捷键 | 功能  |
| --- | --- |
| `a` | 在光标后插入文本 |
| `A` | 在行末插入文本 |
| `i` | 在光标前插入文本 |
| `o` | （小写字母 o）在光标下方新开一行 |
| `O` | （大写字母 O）在光标上方新开一行 |

### 特殊插入

| 快捷键 | 功能  |
| --- | --- |
| `:r [filename]` | 在光标下方插入文件 \[filename\] 的内容 |
| `:r ![command]` | 执行命令 \[command\] ，并将输出插入至光标下方 |

### 删除文本

| 快捷键 | 功能  |
| --- | --- |
| `x` | 删除光标处字符 |
| `dw` | 删除一个词 |
| `d0` | 删至行首 |
| `d$` | 删至行末 |
| `d)` | 删至句末 |
| `dgg` | 删至文件开头 |
| `dG` | 删至文件末尾 |
| `dd` | 删除该行 |
| `3dd` | 删除三行 |

### 简单替换文本

| 快捷键 | 功能  |
| --- | --- |
| `r{text}` | 将光标处的字符替换成 {text} |
| `R` | 进入覆写模式，输入的字符将替换原有的字符 |

### 复制/粘贴文本

| 快捷键 | 功能  |
| --- | --- |
| `yy` | 复制当前行至存储缓冲区 |
| `["x]yy` | 复制当前行至寄存器 x |
| `p` | 在当前行之后粘贴存储缓冲区中的内容 |
| `P` | 在当前行之前粘贴存储缓冲区中的内容 |
| `["x]p` | 在当前行之后粘贴寄存器 x 中的内容 |
| `["x]P` | 在当前行之前粘贴寄存器 x 中的内容 |

### 撤销/重做操作

| 快捷键 | 功能  |
| --- | --- |
| `u` | 撤销最后的操作 |
| `Ctrl+r` | 重做最后撤销的操作 |

### 搜索和替换

| 快捷键 | 功能  |
| --- | --- |
| `/search_text` | 检索文档，在文档后面的部分搜索 search_text |
| `?search_text` | 检索文档，在文档前面的部分搜索 search_text |
| `n` | 移动到后一个检索结果 |
| `N` | 移动到前一个检索结果 |
| `:%s/original/replacement` | 检索第一个 “original” 字符串并将其替换成 “replacement” |
| `:%s/original/replacement/g` | 检索并将所有的 “original” 替换为 “replacement” |
| `:%s/original/replacement/gc` | 检索出所有的 “original” 字符串，但在替换成 “replacement” 前，先询问是否替换 |

### 书签

| 快捷键 | 功能  |
| --- | --- |
| `m {a-zA-Z}` | 在当前光标位置设置书签，书签名可用一个大小写字母（{a-zA-Z}） |
| `:marks` | 列出所有书签 |
| `{a-zA-Z}` | 跳转到书签 {a-zA-Z} |

### 选择文本

| 快捷键 | 功能  |
| --- | --- |
| `v` | 进入逐字可视模式 |
| `V` | 进入逐行可视模式 |
| `Esc` | 退出可视模式 |

### 改动选中文本

| 快捷键 | 功能  |
| --- | --- |
| `~` | 切换大小写 |
| `d` | 删除一个词 |
| `c` | 变更  |
| `y` | 复制  |
| `>` | 右移  |
| `<` | 左移  |
| `!` | 通过外部命令进行过滤 |

### 保存并退出

| 快捷键 | 功能  |
| --- | --- |
| `:q` | 退出 Vim，如果文件已被修改，将退出失败 |
| `:w` | 保存文件 |
| `:w new_name` | 用 new_name 作为文件名保存文件 |
| `:wq` | 保存文件并退出 Vim |
| `:q!` | 退出 Vim，不保存文件改动 |
| `ZZ` | 退出 Vim，如果文件被改动过，保存改动内容 |
| `ZQ` | 与 :q! 相同，退出 Vim，不保存文件改动 |

### 下载 Vim 快捷键速查表

仅仅是这样是否还不足以满足你？别担心，我们已经为你整理好了一份下载版的速查表，以备不时之需。

[点此下载（英文）](http://www.maketecheasier.com/cheatsheet/vim-keyboard-shortcuts-cheatsheet/)

\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-

Vim 编辑器提供了很多的特性，要想全部掌握它们很困难。然而，花费更多的时间在命令行编辑器上总是有帮助的。毫无疑问，和 Vim 用户们进行交流能够让你更快地学习新颖有创造性的东西。

**注：** 本文中用到的例子，使用的 Vim 版本是 7.4.52 。

* * *

## VIM常用场景教程

### 1、 同时编辑多个文件

如果你是一名软件开发者或者把 Vim 作为主要的编辑器，那么可能很多时候你需要同时编辑多个文件。“紧跟（following）”是在同时编辑多个文件时可用的实用技巧。

不需要在多个 shell 界面中打开多个文件，你可以通过把多个文件的文件名作为 Vim 命令的参数从而在一个 shell 界面中打开多个文件。比如：

vim 文件1 文件2 文件3

第一个文件（例子中的文件1）将成为当前文件并被读入缓冲区。

在编辑器中，使用 `:next` 或 `:n` 命令来移动到下一个文件，使用 `:prev` 或 `:N` 命令返回上一个文件。如果想直接切换到第一个文件或最后一个文件，使用 `:bf` 和 `:bl` 命令。特别地，如果想打开另外的文件并编辑，使用 `:e` 命令并把文件名作为参数（如果该文件不在当前目录中则需要完整路径做为参数）。

任何时候如果需要列出当前打开的所有文件，使用 `:ls` 命令。看下面展示的屏幕截图。

![](https://img.linux.net.cn/data/attachment/album/201701/26/141942p7hm7eeieh1j7p1l.png)

注意 ”%a” 表示文件在当前活动窗口，而 “#” 表示上一个活动窗口的文件。

### 2、 通过自动补全节约时间

想节约时间并提高效率吗？使用缩写吧。使用它们能够快速写出文件中多次出现、复杂冗长的词。在 Vim 中缩写命令写就是 `ab` 。

比如，当你运行下面的命令以后：

:ab asap as soon as possible

文件中出现的每一个 `asap` 都会被自动替换为 `as soon as possible` ，就像你自己输入的一样。

类似地，你可以使用缩写来更正常见的输入错误。比如，下面的命令

:ab recieve receive

将会自动更正拼写错误，就像你自己输入的一样。如果在一次特殊情况下你想阻止缩写展开或更正发生，那么你只需要在输入一个单词的最后一个字母以后按 `Ctrl + V` ，然后按空格键。

如果你想把刚才使用的缩写保存下来，从而当你下次使用 Vim 编辑器的时候可以再次使用，那么只需将完整的 `ab` 命令(没有起始的冒号)添加到　`/etc/vim/vimrc` 文件中。如果想删除某个缩写，你可以使用 `una` 命令。比如： `una asap` 。

### 3、 切分窗口便于复制/粘贴

有时，你需要从一个文件将一段代码或文本的一部分复制到另一个。当使用 GUI（图形界面）编辑器的时候，这很容易实现，但是当使用一个命令行编辑器的时候，这就变得比较困难并且很费时间。幸运的是， Vim 提供了一种高效、节约时间的方式来完成这件事。

打开两个文件中的一个然后切分 Vim 窗口来打开另一个文件。可以通过使用 `split` 命令并以文件名作为参数来完成这件事。比如：

:split test.c

上面的命令将分离窗口并打开文件 “test.c”

![](https://img.linux.net.cn/data/attachment/album/201701/26/142000pal6qgf6b5gfffz9.png)

注意到 `split` 命令水平分离 Vim 窗口。如果你想垂直分离窗口，那么你可以使用 `vsplit` 命令。当同时打开了两个文件并从一个文件中复制好内容以后，按 `Ctrl + W` 切换到另一个文件，然后粘贴。

### 4、 保存一个没有权限的已编辑文件

有时候当你对一个文件做了大量更改以后才会意识到你对该文件仅有 `只读` 权限。

![](https://img.linux.net.cn/data/attachment/album/201701/26/142018ytpotpoxntini2oo.png)

虽然把文件关闭，获取权限以后再重新打开是一种解决方法。但是如果你已经做了大量更改，这样做会很浪费时间，因为在这个过程中所有的更改都会丢失。 Vim 提供了一种方式来处理这种情况：你可以在编辑器中在保存文件前更改文件权限。命令是：

:w !sudo tee %

这个命令将会向你询问密码，就像在命令行中使用 `sudo` 一样，然后就能保存更改。

**一个相关的技巧**：在 Vim 中编辑一个文件的时候，如果想快速进入命令行提示符，可以在编辑器中运行 `:sh` 命令，从而你将进入一个交互的 shell 中。完成以后，运行 `exit` 命令可以快速回到 Vim 模式中。

### 5、 在复制/粘贴过程中保持缩进

大多数有经验的程序员在 Vim 上工作时都会启用自动缩进。虽然这是一个节约时间的做法，但是在粘贴一段已经缩进了的代码的时候会产生新的问题。比如，下图是我把一段已缩进代码粘贴到一个在自动缩进的 Vim 编辑器中打开的文件中时遇到的问题：

![](https://img.linux.net.cn/data/attachment/album/201701/26/142034q67v77brs7d7ts7s.png)

这个问题的解决方法是 `pastetoggle` 选项。在 `/etc/vim/vimrc` 文件中加入下面这行内容：

set pastetoggle=

然后当你在 `插入` 模式中准备粘贴代码前先按 `F2` 键，就不会再出现上图中的问题，这样会保留原始的缩进。注意，你可以用其他的任何键来代替 `F2`，如果它已经映射到了别的功能上。

### 结论

更进一步的提高你的 Vim 编辑器技巧的唯一方法是，在你日复一日的工作中使用命令行编辑器。留意那些耗时多的操作，然后尝试去寻找是否有编辑器命令可以很快地完成这个操作。


via: https://www.maketecheasier.com/vim-tips-tricks-for-experienced-users/

作者：[Himanshu Arora](https://www.maketecheasier.com/author/himanshu/) 译者：[ucasFL](https://github.com/ucasFL) 校对：[wxy](https://github.com/wxy)

本文由 [LCTT](https://github.com/LCTT/TranslateProject) 原创编译，[Linux中国](https://linux.cn/article-8148-1.html) 荣誉推出

\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-

> 作者：卢钧轶(cenalulu)
> 来自：http://cenalulu.github.io/linux/all-vim-cheatsheat/


* * *

## 经典版(图文教程)

下面这个键位图应该是大家最常看见的经典版了。

[<img alt="classic" class="alignnone size-full wp-image-14328 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/classic1.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/classic1.gif)

### 对应的简体中文版

[<img alt="vi-vim-cheat-sheet-sch" class="alignnone size-full wp-image-14329 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-cheat-sheet-sch1.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-cheat-sheet-sch1.gif)

### 其实经典版是一系列的入门教程键位图的组合结果，下面是不同编辑模式下的键位图。

[<img alt="vi-vim-tutorial-1" class="alignnone size-full wp-image-14330 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-1.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-1.gif)

[<img alt="vi-vim-tutorial-2" class="alignnone size-full wp-image-14331 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-2.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-2.gif)

[<img alt="vi-vim-tutorial-3" class="alignnone size-full wp-image-14332 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-3.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-3.gif)

[<img alt="vi-vim-tutorial-4" class="alignnone size-full wp-image-14333 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-4.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-4.gif)

[<img alt="vi-vim-tutorial-5" class="alignnone size-full wp-image-14334 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-5.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-5.gif)

[<img alt="vi-vim-tutorial-6" class="alignnone size-full wp-image-14335 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-6.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-6.gif)

[<img alt="vi-vim-tutorial-7" class="alignnone size-full wp-image-14336 jop-noMdConv" src="https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-7.gif" width="1024" height="724">](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-tutorial-7.gif)



* * *

## 参考

https://www.runoob.com/w3cnote/all-vim-cheatsheat.html

https://linux.cn/article-8144-1.html

https://linux.cn/article-8148-1.html
