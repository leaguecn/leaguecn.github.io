## 简介（Introduction）


这是本人博客的资源文件以及Hexo博客框架配置的仓库。    
This repo is backup of my blogger sources and hexo settings.     
博客站点（blog site）：https://leaguecn.github.io/    

*2019-04*

## Update Log

+ 使用新的包管理工具yarn；
+ 更新nexT主题到最新版本（2023/06/11）；
+ 修改mathjax、mermaid配置以适配新版本主题。

*on 2023/06/11, Foshan CC*

* * *

+ renew the next theme config
+ simplify the thread

*2021/04/15, in Foshan City.*

* * *

+ add google site verification

*2019/05/17, in xuzhou*


